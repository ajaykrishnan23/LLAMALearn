import json
import boto3
import time
import requests
import hashlib

from opensearchpy import OpenSearch

# Use the IPv4 URL provided by your AWS OpenSearch Service
host = 'search-llama-index1-jim3gvptncs26357v32o5x5wsi.us-east-1.es.amazonaws.com' 

# Assuming you have set up your OpenSearch cluster to use HTTPS
port = 443
use_ssl = True

auth = ('dads', 'bigData0192*')  # Replace with your credentials

# Create the OpenSearch client
client = OpenSearch(
    hosts=[{'host': host, 'port': port}],
    http_auth=auth,
    use_ssl=use_ssl,
    verify_certs=True,
    ssl_show_warn=False
)

# Check OpenSearch cluster health
print(client.cluster.health())
index_name = 'chunk2vec'

def get_embeddings(text):
    # The URL where your Flask app is running
    # Change the port if necessary, depending on how you mapped the ports in the Docker container
    
    url = 'http://ac43a727c599641fdb076990e4d228d1-490406072.us-east-1.elb.amazonaws.com:80/convert_chunks'

    data = {
        'chunks': text
    }
    
    # Send a POST request
    response = requests.post(url, json=data)
    
    # Check if the request was successful
    if response.status_code == 200:
        print('Response from server:', response.json())
        return response.json()['embeddings']
    else:
        print('Error:', response.status_code)
        return None
    


# from sentence_transformers import SentenceTransformer
def start_text_detection(bucket, document_name):
    textract_client = boto3.client('textract', region_name='us-east-1', api_version='2018-06-27')
    # Start document text detection
    response = textract_client.start_document_text_detection(
        DocumentLocation={'S3Object': {'Bucket': bucket, 'Name': document_name}}
    )
    
    return response['JobId']


def wait_for_completion(textract_client, job_id):
    retries = 0
    while retries < 10:
        # Get the status of the job
        response = textract_client.get_document_text_detection(JobId=job_id)
        status = response['JobStatus']
        if status in ['SUCCEEDED', 'FAILED']:
            break
        time.sleep(10)
        retries += 1
    return status


def process_document(bucket, document_name):
    textract_client = boto3.client('textract', region_name='us-east-1', api_version='2018-06-27')
    try:
        # Synchronously detect text in a document
        response = textract_client.detect_document_text(
            Document={'S3Object': {'Bucket': bucket, 'Name': document_name}}
        )

        chunks = []
        accumulated_text = ""
        words_count = 0

        # Iterate over detected text blocks
        for item in response['Blocks']:
            if item['BlockType'] == 'LINE':
                accumulated_text += item['Text'] + ' '
                words_count += len(item['Text'].split())
                if words_count >= 250:
                    chunks.append(accumulated_text.strip())
                    accumulated_text = ""
                    words_count = 0

        # Add remaining text to chunks
        if accumulated_text:
            chunks.append(accumulated_text.strip())

        return chunks

    except Exception as e:
        print(f"Error processing document {document_name}: {str(e)}")
        return []



def lambda_handler(event, context):
    # From the S3 Event message structure Get bucket and file name
    print("Started")
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    print(bucket)
    print(key)
    
    s3_client = boto3.client('s3')
    chunks = list()
    
    document_name = key
    print(f"Processing document: {document_name}")
    chunks.extend(process_document(bucket, document_name))
    embeddings = get_embeddings(chunks)
    
    hasher = hashlib.sha256()
    object = s3_client.get_object(Bucket = bucket, Key = key)
    file_stream = object["Body"]
    while True:
        data = file_stream.read(1024)
        if not data:
            break
        hasher.update(data)
    doc_hash = hasher.hexdigest()
    print(f"Printing doc hash {doc_hash}")    
  
    
    for i, (vector, text) in enumerate(embeddings):
        document = {
        'embedding': vector,
        'text': text,
        'doc_id':doc_hash
        }
        client.index(index=index_name, id=f"{doc_hash}_{str(i)}", body=document)
    
    
    
    response = {
        'docId': doc_hash
    }

    return {
        'statusCode': 200,
        'body': json.dumps(response),
    }