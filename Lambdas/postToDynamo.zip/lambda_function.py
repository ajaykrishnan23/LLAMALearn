import boto3
import uuid
import json
import requests 

from opensearchpy import OpenSearch

# Use the IPv4 URL provided by your AWS OpenSearch Service
host = 'search-llama-index1-jim3gvptncs26357v32o5x5wsi.us-east-1.es.amazonaws.com' 
llm_host = 'http://a7b69795591cb4696bac02eea19bd2ff-1540327508.us-east-1.elb.amazonaws.com/get_answer'

# Assuming you have set up your OpenSearch cluster to use HTTPS
port = 443
use_ssl = True

auth = ('dads', 'bigData0192*')  # Replace with your credentials

# Create the OpenSearch client
client = OpenSearch(
    hosts=[{'host': host, 'port': port}],
    http_auth=auth,
    use_ssl=use_ssl,
    verify_certs=True,
    ssl_show_warn=False
)

# Check OpenSearch cluster health
print(client.cluster.health())
index_name = 'chunk2vec'

def get_embeddings(text):
    # The URL where your Flask app is running
    # Change the port if necessary, depending on how you mapped the ports in the Docker container
    
    url = 'http://ac43a727c599641fdb076990e4d228d1-490406072.us-east-1.elb.amazonaws.com:80/convert_chunks'

    data = {
        'chunks': text
    }
    
    # Send a POST request
    response = requests.post(url, json=data)
    
    # Check if the request was successful
    if response.status_code == 200:
        print('Response from server:', response.json())
        return response.json()['embeddings']
    else:
        print('Error:', response.status_code)
        return None

def perform_QnA(question, doc_id):
    query_vector, _ = get_embeddings(question)[0]
    
    knn_query = {
    "size": 1,  # Adjust 'size' as needed
    "query": {
        "bool": {
            "must": {
                "knn": {
                    "embedding": {
                        "vector": query_vector,  # Replace with your vector values
                        "k": 1  # Adjust 'k' as needed
                    }
                }
            },
            "filter": {
                "term": {"doc_id": doc_id}  # Replace with your specific doc_id
            }
        }
    }
    }
    
    response = client.search(index=index_name, body=knn_query)
    
    documents = response['hits']['hits']
    context = ''
    # Optionally, process the results
    for doc in documents:
        print(doc['_score'])
        print(doc['_source']['text'])  # Replace with your processing logic
        print('----')
        context += doc['_source']['text']
        
    
    # Example data to send
    data = {
        'question': question,
        "context": context
    }
    # Send a POST request
    headers = {
        "Content-Type": "application/json",
        "Api-Key": "Shoshoshoshona"
    }
    print("Pre passing to model")
    print(data)
    response = requests.post(llm_host, json=data, headers=headers)
    
    return response.json().get('answer',{}).get('choices',[{}])[0].get('text',None)

def lambda_handler(event, context):
    '''
    1. take the question and hit get embeddings
    2. get the embeddings, hit es and get context 
    3. send context and question to model 
    4. get response and modify item_data
    '''
    
    print(event)
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')  # Replace 'your_region' with your AWS region

    # Specify the table name
    table_name = 'user-qna'
    
    # Get a reference to the DynamoDB table
    table = dynamodb.Table(table_name)
    
    body = json.loads(event['body'])
    item_data = {
        "uqid":body['userId'],
        "documentId":body['documentId'],
        "q": body["q"],
        "a" : "" 
    }
    
    answer = perform_QnA(item_data['q'],body['documentId'])
    item_data['a'] = answer
    
    
    try:
        # Add the item to the DynamoDB table
        table.put_item(Item=item_data)
        print("PutItem succeeded:")
        response = {
            'statusCode': 200,
            'headers': {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "*",  # Specify the allowed headers
                "Access-Control-Allow-Methods": "*",  # Specify the allowed HTTP methods
            },
            'body': json.dumps({'message': 'DynamoDB insertion successful'})
        }
    except Exception as e:
        print(f"Error: {str(e)}")
        response = {
            'statusCode': 500,
            'headers': {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "*",  # Specify the allowed headers
                "Access-Control-Allow-Methods": "*",  # Specify the allowed HTTP methods
            },
            'body': json.dumps({'error': 'Internal Server Error'})
        }

    return response